-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 24 ديسمبر 2022 الساعة 18:27
-- إصدار الخادم: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sianeh`
--

-- --------------------------------------------------------

--
-- بنية الجدول `book`
--

CREATE TABLE `book` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tcost` varchar(20) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `dateoforder` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `workername` varchar(20) NOT NULL,
  `phone` int(10) NOT NULL,
  `twork` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `book`
--

INSERT INTO `book` (`id`, `name`, `email`, `tcost`, `cost`, `dateoforder`, `workername`, `phone`, `twork`) VALUES
(2, 'dd', 'admindfds@s', '', '', '2022-12-03 00:00:00', '', 799999999, ''),
(3, 'dds', 'admindfds@swl', '', '', '2022-12-03 00:00:00', '', 799999992, ''),
(4, 'rr', 'aboodj560@gmail.com', '', '', '2022-12-31 00:00:00', '', 799999966, ''),
(5, 'zzz', 'admin@gmail.com', '50', '', '2022-12-20 11:55:57', 'ali', 799999997, 'مواسرجي'),
(6, 'zzz', 'admin@gmail.com', '', '', '2022-12-19 13:13:32', 'asddsded', 799999997, 'دهين'),
(7, 'abood', 'w@gmail.com', '40', '', '2022-12-24 13:06:21', 'ali', 782928699, 'مواسرجي'),
(8, 'abood', 'w@gmail.com', '', '', '2022-12-19 20:46:24', 'aq', 782928699, 'مواسرجي'),
(9, 'zzz', 'admin@gmail.com', '150', '', '2022-12-24 13:54:16', 'ali', 799999997, 'مواسرجي'),
(10, 'zzz', 'admin@gmail.com', '', '', '2022-12-20 14:49:44', '', 799999997, '0'),
(11, 'zzz', 'admin@gmail.com', '30', '', '2022-12-20 14:57:08', 'ali', 799999997, 'مواسرجي');

-- --------------------------------------------------------

--
-- بنية الجدول `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `comm` varchar(50) NOT NULL,
  `dateofcomm` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `comment`
--

INSERT INTO `comment` (`id`, `name`, `comm`, `dateofcomm`) VALUES
(1, 'waleed', ' \r\nالبرنامج ممتاز', '2022-12-19 10:10:11'),
(2, 'عبود', 'الدكتور الكوفحي احسن دكتور     ', '2022-12-19 10:10:21'),
(3, '', 'df,,dfjd,fjd,fjd,jd,sdj', '2022-12-18 19:49:05'),
(4, '', 'اسمك  \r\n       ', '2022-12-19 09:05:03'),
(5, 'zzz', ' \r\nft5tft5tf       ', '2022-12-19 09:51:52'),
(6, 'zzz', ' \r\nthnx       ', '2022-12-19 10:11:03'),
(7, 'zzz', ' \r\nsdsdsd       ', '2022-12-20 11:46:55'),
(8, 'zzz', '', '2022-12-21 11:46:26'),
(9, 'zzz', 'hg\r\n       ', '2022-12-21 11:46:50'),
(10, 'zzz', 'ckxjkdjckxjckxjckjdkjfskdh44 \r\n       ', '2022-12-21 13:20:32'),
(11, 'zzz', ' \r\nfjfjdkfdkfjdkjfkdfjkdfj\r\n       ', '2022-12-21 13:21:36'),
(12, 'zzz', ' \r\nfjfjdkfdkfjdkjfkdfjkdfj\r\nسييسسيسيسي       ', '2022-12-21 13:24:13'),
(13, 'zzz', ' \r\nيبةيبنيبتنيبتنتيبنيتب       ', '2022-12-21 13:28:15'),
(14, 'zzz', 'gljdlgjdlgjldgjkgfkgjflg       ', '2022-12-21 14:39:37'),
(15, 'zzz', ' \r\ndfgdfgdfdf       ', '2022-12-21 14:49:30'),
(16, 'zzz', ' \r\nddddddsvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv', '2022-12-21 14:51:38'),
(17, 'zzz', ' \r\ndfffffffffffffffffffffffff       ', '2022-12-21 14:56:26');

-- --------------------------------------------------------

--
-- بنية الجدول `complaint`
--

CREATE TABLE `complaint` (
  `name` varchar(40) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(10) NOT NULL,
  `complaint1` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `complaint`
--

INSERT INTO `complaint` (`name`, `email`, `phone`, `complaint1`) VALUES
('zzz', 'admin@gmail.com', 799999997, 'hhhghg'),
('abood', 'w@gmail.com', 782928699, 'gfhfhfhfhfh'),
('zzz', 'admin@gmail.com', 799999997, 'ghghghghgh');

-- --------------------------------------------------------

--
-- بنية الجدول `cridet`
--

CREATE TABLE `cridet` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `crnum` int(40) NOT NULL,
  `crex` int(40) NOT NULL,
  `cvc` int(40) NOT NULL,
  `hname` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `cridet`
--

INSERT INTO `cridet` (`id`, `name`, `crnum`, `crex`, `cvc`, `hname`) VALUES
(1, '', 0, 0, 0, '0'),
(2, '', 0, 0, 0, ''),
(3, '', 0, 0, 0, ''),
(4, '', 0, 0, 0, ''),
(5, '', 0, 0, 0, ''),
(6, '', 0, 0, 0, ''),
(7, '', 0, 6666, 5555, '21312321321');

-- --------------------------------------------------------

--
-- بنية الجدول `finance`
--

CREATE TABLE `finance` (
  `id` int(11) NOT NULL,
  `cost` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- بنية الجدول `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `login`
--

INSERT INTO `login` (`id`, `user_name`, `password`) VALUES
(1, 'waleed', 'w12'),
(2, 'admin@gmail.com', 'w12'),
(4, 'w1@gmail.com', 'w12'),
(5, 'wamsianeh', '12345'),
(6, 'q@gmail.com', '12qw'),
(7, 'h@gmail.com', 'qw12'),
(8, 'admin@fgfg', '111');

-- --------------------------------------------------------

--
-- بنية الجدول `movements`
--

CREATE TABLE `movements` (
  `name` varchar(50) NOT NULL,
  `time` datetime NOT NULL,
  `typeofmovements` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- بنية الجدول `signupu`
--

CREATE TABLE `signupu` (
  `id` int(11) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `signupu`
--

INSERT INTO `signupu` (`id`, `fname`, `lname`, `email`, `password`, `phone`) VALUES
(1, 'zzz', 'assas', 'admin@gmail.com', 'w12', 799999997),
(3, 'w', 'q', 'admin@fgfg', '111', 788887834);

-- --------------------------------------------------------

--
-- بنية الجدول `signupw`
--

CREATE TABLE `signupw` (
  `id` int(11) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone` int(10) NOT NULL,
  `location` varchar(15) NOT NULL,
  `colleg` varchar(20) NOT NULL,
  `age` int(49) NOT NULL,
  `numofwork` int(100) NOT NULL,
  `typeofjob` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `signupw`
--

INSERT INTO `signupw` (`id`, `fname`, `lname`, `email`, `password`, `phone`, `location`, `colleg`, `age`, `numofwork`, `typeofjob`) VALUES
(1, 'asddsded', 'assas', 'w1@gmail.com', '', 799282968, 'عمان', 'بكالوريوس', 21, 50, 'دهين'),
(2, 'ali', 'qq', 'q@gmail.com', '12qw', 799959997, 'عمان', 'بكالوريوس', 35, 44, 'مواسرجي'),
(3, 'aq', 'hg', 'h@gmail.com', 'qw12', 799999990, 'عمان', 'بكالوريوس', 22, 33, 'مواسرجي');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cridet`
--
ALTER TABLE `cridet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `finance`
--
ALTER TABLE `finance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signupu`
--
ALTER TABLE `signupu`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `signupw`
--
ALTER TABLE `signupw`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `cridet`
--
ALTER TABLE `cridet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `finance`
--
ALTER TABLE `finance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `signupu`
--
ALTER TABLE `signupu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `signupw`
--
ALTER TABLE `signupw`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
